function [seq,fs] = DTMFsequence(filename)
% DTMFsequence identifies the sequence of key presses based on a given
% audio signal
% Parameters:
%   filename - *.wav file that contains a single DTMF signal
% Outputs:
%   key      - a character corresponding to one of twelve possible keys
%   fs       - sampling rate in Hz

% extracting audio signal
[y, fs] = audioread(filename);

% ACCOUNTING FOR NOISE - Bandpass Filter
x = DTMFbandpass(y,fs);

% smoothing function
x = movmean(x, round(0.002*fs));

n = length(x);

% calculating energy for each segment of time
window_length = round(0.02*fs); % minimum length of signal is 20 ms -> minimum length of window
shift_length = round(0.005*fs); % shifting by 5 ms (overlapping windows)

% calculating whether or not each window of the signal has energy and
% storing that information in key_press as sequence of 1s (has energy) and
% 0s (no energy)
key_press = energyWindows(x, window_length, shift_length);

% calculating places where energy changes
change_in_key = diff(key_press);

% calculating boundaries of each individual signal
[start_indices, end_indices] = signalBounds(x, key_press, change_in_key, shift_length, fs);

seq = "";

% decoding the signals
for i = 1:min(length(start_indices),length(end_indices)) 
    % extracting the start and end indices of each signal
    k = start_indices(i);
    j = end_indices(i);

    signal_window = x(k:j);

    % if the signal is less than minimum length of a signal -> IGNORE
    if length(signal_window) < round(0.02 * fs)
        continue; 
    end

    % decode the signal!
    key = DTMFdecode_signal(signal_window, fs);
    seq = seq + key;

end

end

