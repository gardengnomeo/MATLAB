function [x,fs] = DTMFencode(key,duration, weight, fs)
% DTMFencode generates a DTMF tone for a given key and following parameters
% Parameters:
%   key      - a character ( one of 12 possible keys:'0'-'9', '*', '#')
%   duration - (optional, default 0.2 s) duration of the signal in seconds
%   weight   - (optional, default [1,1]) 1x2 vector of weights for [low, high] frequencies
%   fs       - (optional, default 8000 Hz) sampling rate (must be >= 3000)
% Outputs:
%   x        - generated DTMF signal based on pressed key
%   fs       - sampling rate in Hz

if nargin == 4 && fs < 3000
    error("sampling rate must be at least 3000 Hz");
end

if nargin < 4
    fs = 8000;
end
if nargin < 3
    weight = [1,1];
end
if nargin < 2
    duration = 0.2;
end
if nargin < 1
    error("Must specify a key");
end

% corresponding digits: 1, 2, 3, 4, 5, 6, 7, 8, 9, *, 0, #
key_high_freq = [1209, 1336, 1477, 1209, 1336, 1477,1209, 1336, 1477,1209, 1336, 1477];
key_low_freq = [697, 697, 697, 770, 770, 770, 852, 852, 852, 941, 941, 941];

% assigning the appropriate indices
if key == '*'
    key_index = 10;
elseif key == '#'
    key_index = 12;
elseif key == '0'
    key_index = 11;
else
    key_index = str2double(key);
end

% creating sine waves for high frequency and low frequency components
t = 0:1/fs:duration;
high_freq_component = weight(2) * sin(2*pi*key_high_freq(key_index)*t);
low_freq_component = weight(1) * sin(2*pi*key_low_freq(key_index)*t);

% summing the high frequency waveform and low frequency waveform
x = high_freq_component + low_freq_component;
% normalizing the signal
x = x/max(abs(x));

end

