function [start_indices,end_indices] = signalBounds(x, key_press, change_in_key, s, fs)
% SIGNALBOUNDS calculates the bounds of each individual signal given a
% sequence of individual signals
%
% Parameters:
%   x       - signal to calculate the boundaries 
% Outputs:
%   y       - the signal x after the bandpass filter is applied

n = length(x);
% arrays to hold start and end indices of individual signals
signal_start_bounds = zeros(1,n);
signal_end_bounds = zeros(1,n);

% if x starts with a signal
if key_press(1) == 1
    signal_start_bounds(1) = 1;
end

% calculating the bounds of each signal
for k = 1:length(change_in_key)
    % if going from window of no energy to window with energy (signal start)
    if change_in_key(k) == 1
        % need to calculate where this corresponds to in x(t)
        start_idx = k*s+1;
        signal_start_bounds(start_idx) = 1;
    end
    % if going from window with energy to window of no energy (signal ends)
    if change_in_key(k) == -1
        end_idx = k*s+1;
        signal_end_bounds(end_idx) = 1;
    end
end

% marking corresponding indices
start_indices = find(signal_start_bounds);
end_indices = find(signal_end_bounds);
% accounting for case where signal is still going at end of window
if length(start_indices) > length(end_indices)
    end_indices = [end_indices n];
end

% checking that each identified signal is valid
min_silence = round(0.02 * fs);
min_duration = round(0.02 * fs);

valid_sound = [1];
for k = 2:length(start_indices)
    duration = end_indices(k) - start_indices(k);
    silence = start_indices(k) - end_indices(valid_sound(end));
    % signal is only valid if it has a silence of more than 20 ms
    % and if it is longer than 20 ms in duration
    if silence > min_silence && duration > min_duration
        valid_sound(end+1) = k;
    end
end

% use logical indexing to remove invalid indices (and keep valid ones)
start_indices = start_indices(valid_sound);
end_indices = end_indices(valid_sound);
end

