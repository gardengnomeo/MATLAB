function [y] = DTMFbandpass(x, fs)
% DTMFBANDPASS acts as a "bandpass filter" for the signal x
% it only allows frequencies relevant to DTMF to pass through, and removes
% all irrelvant frequencies from the signal
% Parameters:
%   x       - signal to apply the bandpass filter to
%   fs      - sampling rate of signal x
% Outputs:
%   y       - the signal x after the bandpass filter is applied

temp = fft(x);
temp_freq_vector = (0:length(x)-1)*(fs/length(x));
temp(~((temp_freq_vector >= 645 & temp_freq_vector <= 1500) | (temp_freq_vector >= (fs-1520) & temp_freq_vector <= (fs-640)))) = 0;
y = ifft(temp, 'symmetric');

end

