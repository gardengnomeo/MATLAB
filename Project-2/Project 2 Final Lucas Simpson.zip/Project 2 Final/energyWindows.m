function [y] = energyWindows(x,w,s)
% calculates the energy for each window of time
% Parameters:
%   x       - signal to calculate the energy windows of
%   w       - the number of windows in the signal
%   s       - the shift size for each window
% Outputs:
%   y       - vector of 1s and 0s representing whether or not the signal
%             has energy

% calculating the number of windows in the signal
n = floor((length(x)-w)/s);

% creating a vector to hold energy calculations
energy = zeros(1,n);

% calculating energy of each window
for k = 1:n
    window = (1:w)+(k-1)*s;
    energy(k) = sum(abs(x(window)).^2);
end

% finding threshold value for energy
threshold = 0.025*max(energy);

% identifying where there is energy (meaning there is a key being pressed)
y = energy > threshold;

end

