% 1.2 & 1.3: generating audio files for all 12 possible digits using default parameters

t = 0:1/8000:0.2;

for k=0:9
    key = num2str(k);
    [x,fs] = DTMFencode(key);
    filename = ['digit waves/digit', key, '.wav'];
    audiowrite(filename,x,fs);

    figure(k+1);
    figure('Position', [100, 100, 800, 400]);
    subplot(2,1,1);
    plot(t,x);
    title1 = ['Time-Domain Signal for ', key];
    title(title1);
    xlabel('Time (seconds)');
    ylabel('Amplitude');
    subplot(2,1,2);
    n = length(x);
    f_centered = (-n/2:n/2-1)*(8000/n);
    plot(f_centered,abs(fftshift(fft(x)))/n);
    title2 = ['Magnitude of Fourier Transform of x(t) for ', key];
    title(title2);
    xlabel('Frequency (Hz)');
    ylabel('Magnitude');
end

[x,fs] = DTMFencode('*');
audiowrite("digit waves/digitStar.wav",x,fs);
figure(11);
figure('Position', [100, 100, 800, 400]);
subplot(2,1,1);
plot(t,x);
title('Time-Domain Signal of *');
xlabel('Time (seconds)');
ylabel('Amplitude');
subplot(2,1,2);
n = length(x);
f_centered = (-n/2:n/2-1)*(8000/n);
plot(f_centered,abs(fftshift(fft(x)))/n);
title('Magnitude of Fourier Transform of x(t) for *');
xlabel('Frequency (Hz)');
ylabel('Magnitude');

[x,fs] = DTMFencode('#');
audiowrite("digit waves/digitPound.wav",x,fs);
figure(12);
figure('Position', [100, 100, 800, 400]);
subplot(2,1,1);
plot(t,x);
title('Time-Domain Signal of #');
xlabel('Time (seconds)');
ylabel('Amplitude');
subplot(2,1,2);
n = length(x);
f_centered = (-n/2:n/2-1)*(8000/n);
plot(f_centered,abs(fftshift(fft(x)))/n);
title('Magnitude of Fourier Transform of x(t) for #');
xlabel('Frequency (Hz)');
ylabel('Magnitude');