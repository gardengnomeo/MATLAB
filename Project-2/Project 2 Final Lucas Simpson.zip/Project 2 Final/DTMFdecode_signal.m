function [key] = DTMFdecode_signal(x, fs)
% DTMFdecode identifies the key given a singular DTMF tone
% Parameters:
%   x        - the signal
%   fs       - sampling rate in Hz
% Outputs:
%   key      - a character corresponding to one of twelve possible keys

% fourier transform of x(t)
y = abs(fft(x));

% only need first half of fourier transform (don't need mirror)
n = length(x);
y = y(1:floor(n/2));
w = (0:floor(n/2)-1)*(fs/n);

% splitting w into the low-frequency and high-frequency spectrums
w_low = w>= 650 & w <= 1000;
w_high = w>=1150 & w<= 1520;

% identifying frequencies where top peak occurs in low-frequency and
% high-frequency spectrums
[~, low_freq_index] = max(y(w_low));
[~, high_freq_index] = max(y(w_high));

% find corresponding absolute index of low and high frequencies
low_indices = find(w_low);
high_indices = find(w_high);

low_index = low_indices(low_freq_index);
high_index = high_indices(high_freq_index);

low_freq = w(low_index);
high_freq = w(high_index);

% finding closest matching frequencies
key_low_freq = [697, 770, 852, 941];
key_high_freq = [1209, 1336, 1477];

distances_low = abs(low_freq - key_low_freq);
[~, il] = min(distances_low);
distances_high = abs(high_freq - key_high_freq);
[~, ih] = min(distances_high);

% finding which key this corresponds to
keys = {'1', '2', '3';
        '4', '5', '6';
        '7', '8', '9';
        '*', '0', '#'};

key = keys(il,ih);
end

