% x1 = DTMFencode('1', 0.5);
% x2 = DTMFencode('2', 0.4);
% x3 = DTMFencode('3', 0.3, [1,2]);
% x5 = DTMFencode('5');
% space = zeros(1, round(0.1 * 8000));
% space2 = zeros(1, round(0.05*8000));
% x = [x1 space x2 space x3 space x5 space2 x5 space2 space x5];
% audiowrite('test1.wav',x,8000);
% [seq, fs] = DTMFsequence('test1.wav');
% seq

for k = 1:20
    filename = ['DTMFexamples/dtmf', num2str(k),'.wav'];
    [seq, fs] = DTMFsequence(filename);
    dispMessage = "dtmf" + num2str(k) + ": " + seq;
    disp(dispMessage);
end

% filename = ['DTMFexamples/dtmf', num2str(13),'.wav'];
% [seq, fs] = DTMFsequence(filename);
% seq

% [x,fs] = DTMFencode('*',1,[0.75, 1], 4000);
% noise = randn(1,length(x));
% x_w_noise = x + noise;
% x_w_noise = x_w_noise / max(abs(x_w_noise));
% audiowrite('testing_with_noise.wav', x_w_noise, fs);
% [key, fs] = DTMFdecode('testing_with_noise.wav');
% key

%[x,fs] = DTMFencode('5',0.5,[1, 1.5]);
%x = x/max(abs(x));
%audiowrite('testing.wav', x, fs);
%[key, fs] = DTMFdecode('testing.wav');
%key

